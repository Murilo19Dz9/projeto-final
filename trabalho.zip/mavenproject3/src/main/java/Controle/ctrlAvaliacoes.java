/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

import Modelo.Avaliacoes;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Murilo
 */
public class ctrlAvaliacoes {
    
    private final Avaliacoes objAvaliacoes;
    
    public ctrlAvaliacoes(){
        this.objAvaliacoes = new Avaliacoes();
    }
    
    public int Salvar(ArrayList<String> pLista){
        this.objAvaliacoes.setData_avaliacoes(pLista.get(1));
        this.objAvaliacoes.setNome_materia(pLista.get(2));
        this.objAvaliacoes.setTipo_atividade(pLista.get(3));
        this.objAvaliacoes.setProximoCodigo();
        this.objAvaliacoes.Salvar();
        return this.objAvaliacoes.getCodigo();
    }
    
    public void Excluir (int Chave){
        this.objAvaliacoes.setCodigo(Chave);
        this.objAvaliacoes.Excluir(Chave);
    }
    
    public void Atualizar (ArrayList<String> pLista){
        this.objAvaliacoes.setCodigo(Integer.valueOf(pLista.get(0)));
        this.objAvaliacoes.setData_avaliacoes(pLista.get(1));
        this.objAvaliacoes.setNome_materia(pLista.get(2));
        this.objAvaliacoes.setTipo_atividade(pLista.get(3));
        
        this.objAvaliacoes.Atualizar();
        
    }
    
    public ArrayList<String> ConverterObjetoParaArray(){
        ArrayList<String>vetCampos = new ArrayList<>();
        vetCampos.add(String.valueOf(this.objAvaliacoes.getCodigo()));
        vetCampos.add(this.objAvaliacoes.getData_avaliacoes());
        vetCampos.add(this.objAvaliacoes.getNome_materia());
        vetCampos.add(this.objAvaliacoes.getTipo_atividade());
        
        return vetCampos;
    }
    
    public ArrayList<String> RecuperaObjeto(int Codigo){
        this.objAvaliacoes.RecuperarObjeto(Codigo);
        return ConverterObjetoParaArray();
    }
    
    public ArrayList<String>RecuperaObjetoNavegacao (int Opcao, int Codigo){
        this.objAvaliacoes.RecuperaObjetoPelaNavegacao(Opcao, Codigo);
        return ConverterObjetoParaArray();
    }
    
    public DefaultTableModel PesquisaObjeto (ArrayList<String> Parametros, DefaultTableModel ModeloTabela){
        String Campo = Parametros.get(0);
        String Valor = Parametros.get(1);
        
        ArrayList<Avaliacoes> Avaliacoess = this.objAvaliacoes.RecuperaObjetos(Campo, Valor);
        
        Vector<String> vetVetor;
        Avaliacoes objAvaliacoesBuffer;    
        
        for (int i = 0; i < Avaliacoess.size(); i++) {
            vetVetor = new Vector<>();
            objAvaliacoesBuffer = Avaliacoess.get(i);
            
            vetVetor.addElement(String.valueOf(objAvaliacoesBuffer.getCodigo()));
            vetVetor.addElement(objAvaliacoesBuffer.getData_avaliacoes());
            vetVetor.addElement(objAvaliacoesBuffer.getNome_materia());
            vetVetor.addElement(objAvaliacoesBuffer.getTipo_atividade());
            ModeloTabela.addRow(vetVetor);        
        }
        return ModeloTabela;
    }
}
