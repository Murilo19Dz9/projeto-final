/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Materia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Murilo
 */
public class MateriaDAO {
    public static final int cNavPrimeiro = 0;
    public static final int cNavAnterior = 1;
    public static final int cNavProximo = 2;
    public static final int cNavUltimo = 3;
    

    public static int PegaCodigoPelaNavegacao(int iOpcao, int iCodigoAtual){
        Connection conexao = FabricaConexao.getConnection();
        
        Statement consulta = null;
        ResultSet resultado = null;        
        int codigoEncontrado = -1;
        
        String sql = "";
        
        switch (iOpcao) {
            case cNavPrimeiro: sql = "select min(CODIGO) as CODIGO from MATERIA"; break;
            case cNavAnterior: sql = "select max(CODIGO) as CODIGO from MATERIA where CODIGO < "+ String.valueOf(iCodigoAtual); break;
            case cNavProximo: sql = "select min(CODIGO) as CODIGO from MATERIA where CODIGO > "+ String.valueOf(iCodigoAtual); break;
            case cNavUltimo: sql = "select max(CODIGO) as CODIGO from MATERIA"; break;
        }
        
        try {
            consulta = (Statement)conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigoEncontrado = resultado.getInt("CODIGO");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        }finally{
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função PegaCodigoPelaNavegação: " + e.getMessage());
            }
        }
        return codigoEncontrado;
    }

    public static int ProximoCodigo() {
        Connection conexao = FabricaConexao.getConnection();

        Statement consulta = null;
        ResultSet resultado = null;
        int codigo = -1;

        String sql = "select max(codigo) as CODIGO from MATERIA";

        try {
            consulta = (Statement) conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigo = resultado.getInt("CODIGO");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Próximo Código: " + e.getMessage());
            }
        }

        return codigo + 1;
    }

    public static void Salvar(Materia materia) {
        Connection conexao = FabricaConexao.getConnection();

        PreparedStatement insereSt = null;

        String sql = "insert materia (CODIGO, MATERIAS, ATIVIDADES_EXTRAS) values (?,?,?)";

        try {

            insereSt = conexao.prepareStatement(sql);
            insereSt.setInt(1, materia.getCodigo());
            insereSt.setString(2, materia.getMaterias());
            insereSt.setString(3, materia.getAtividades_extras());
            insereSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir materia: " + e.getMessage());
        } finally {
            try {
                JOptionPane.showMessageDialog(null, "Materia incluída com sucesso: ");
                insereSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Salvar(): " + e.getMessage());
            }
        }
    }
    
    public static void Atualizar(Materia materia){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement atualizaSt = null;
        
        String sql = "update materia set materias = ?, atividades_extras = ? where codigo = ?";
        
        try {
            atualizaSt = conexao.prepareStatement(sql);
            atualizaSt.setString(1, materia.getMaterias());
            atualizaSt.setString(2, materia.getAtividades_extras());
            atualizaSt.setInt(3, materia.getCodigo());
            atualizaSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar materia: " + e.getMessage());
        }finally{
            try {
                atualizaSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Atualizar(): " + e.getMessage());
            }
        }    
    }
    
    public static void Excluir(int iCod){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement excluiSt = null;
        
        String sql = "delete from materia where codigo = "+iCod;
        
        try {
            excluiSt = conexao.prepareStatement(sql);
            excluiSt.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir materia: " + e.getMessage());
        }finally{
           try {
                excluiSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Excluir(): " + e.getMessage());
            } 
        }
    }

    public static Materia RecuperarMateria(int iCod) {
        Connection conexao = FabricaConexao.getConnection();

        Materia materiaRecuperada = new Materia();
        Statement consulta = null;
        ResultSet resultado = null;

        String sql = "select * from materia where codigo = " + iCod;

        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            resultado.next();
            
            if(resultado.getRow() == 1){
                materiaRecuperada.setCodigo(resultado.getInt("CODIGO"));
                materiaRecuperada.setMaterias(resultado.getString("MATERIAS"));
                materiaRecuperada.setAtividades_extras(resultado.getString("ATIVIDADES_EXTRAS"));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar materia: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Recuperar Materia: " + e.getMessage());
            }
        }   
        
        return materiaRecuperada;
    }
    
    public static ArrayList<Materia>RecuperaObjetos(String pCampo, String pValor){
        Connection conexao = FabricaConexao.getConnection();
        
        ArrayList<Materia> materias = new ArrayList<>();
        
        Statement consulta = null;
        ResultSet resultado = null;
        
        String sql = "select * from MATERIA where "+ pCampo + " like '%"+ pValor + "%'";
        
        
        
        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            while (resultado.next()){
                Materia materiaTemp = new Materia();
                materiaTemp.setCodigo(resultado.getInt("CODIGO"));
                materiaTemp.setMaterias(resultado.getString("MATERIAS"));
                materiaTemp.setAtividades_extras(resultado.getString("ATIVIDADES_EXTRAS"));
                materias.add(materiaTemp);
                
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar materias: " + e.getMessage()+ "\n" + sql);
        }finally{
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função RecuperarObjeto(): " + e.getMessage());
            }
        }
        return materias;
    }
}
