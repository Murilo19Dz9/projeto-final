/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Horario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Murilo
 */
public class HorarioDAO {
    
    public static final int cNavPrimeiro = 0;
    public static final int cNavAnterior = 1;
    public static final int cNavProximo = 2;
    public static final int cNavUltimo = 3;
    

    public static int PegaCodigoPelaNavegacao(int iOpcao, int iCodigoAtual){
        Connection conexao = FabricaConexao.getConnection();
        
        Statement consulta = null;
        ResultSet resultado = null;        
        int codigoEncontrado = -1;
        
        String sql = "";
        
        switch (iOpcao) {
            case cNavPrimeiro: sql = "select min(CODIGO) as CODIGO from HORARIO"; break;
            case cNavAnterior: sql = "select max(CODIGO) as CODIGO from HORARIO where CODIGO < "+ String.valueOf(iCodigoAtual); break;
            case cNavProximo: sql = "select min(CODIGO) as CODIGO from HORARIO where CODIGO > "+ String.valueOf(iCodigoAtual); break;
            case cNavUltimo: sql = "select max(CODIGO) as CODIGO from HORARIO"; break;
        }
        
        try {
            consulta = (Statement)conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigoEncontrado = resultado.getInt("CODIGO");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        }finally{
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função PegaCodigoPelaNavegação: " + e.getMessage());
            }
        }
        return codigoEncontrado;
    }

    public static int ProximoCodigo() {
        Connection conexao = FabricaConexao.getConnection();

        Statement consulta = null;
        ResultSet resultado = null;
        int codigo = -1;

        String sql = "select max(codigo) as CODIGO from HORARIO";

        try {
            consulta = (Statement) conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigo = resultado.getInt("CODIGO");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Próximo Código: " + e.getMessage());
            }
        }

        return codigo + 1;
    }

    public static void Salvar(Horario horario) {
        Connection conexao = FabricaConexao.getConnection();

        PreparedStatement insereSt = null;

        String sql = "insert horario (CODIGO, INICIO_ROTINA, TERMINO_ROTINA, HORARIOS, ATIVIDADE_HORARIOS, TURNO) values (?,?,?,?,?,?)";

        try {

            insereSt = conexao.prepareStatement(sql);
            insereSt.setInt(1, horario.getCodigo());
            insereSt.setString(2, horario.getInicio_rotina());
            insereSt.setString(3, horario.getTermino_rotina());
            insereSt.setString(4, horario.getHorarios());
            insereSt.setString(5, horario.getAtividade_horarios());
            insereSt.setString(6, horario.getTurno());
            insereSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir horario: " + e.getMessage());
        } finally {
            try {
                JOptionPane.showMessageDialog(null, "Horario incluída com sucesso: ");
                insereSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Salvar(): " + e.getMessage());
            }
        }
    }
    
    public static void Atualizar(Horario horario){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement atualizaSt = null;
        
        String sql = "update horario set inicio_rotina = ?, termino_rotina = ?, horarios = ?, atividade_horarios = ?, turno = ? where codigo = ?";
        
        try {
            atualizaSt = conexao.prepareStatement(sql);
            atualizaSt.setString(1, horario.getInicio_rotina());
            atualizaSt.setString(2, horario.getTermino_rotina());
            atualizaSt.setString(3, horario.getHorarios());
            atualizaSt.setString(4, horario.getAtividade_horarios());
            atualizaSt.setString(5, horario.getTurno());
            atualizaSt.setInt(6, horario.getCodigo());
            atualizaSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar horario: " + e.getMessage());
        }finally{
            try {
                atualizaSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Atualizar(): " + e.getMessage());
            }
        }    
    }
    
    public static void Excluir(int iCod){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement excluiSt = null;
        
        String sql = "delete from horario where codigo = "+iCod;
        
        try {
            excluiSt = conexao.prepareStatement(sql);
            excluiSt.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir horario: " + e.getMessage());
        }finally{
           try {
                excluiSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Excluir(): " + e.getMessage());
            } 
        }
    }

    public static Horario RecuperarHorario(int iCod) {
        Connection conexao = FabricaConexao.getConnection();

        Horario horarioRecuperada = new Horario();
        Statement consulta = null;
        ResultSet resultado = null;

        String sql = "select * from horario where codigo = " + iCod;

        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            resultado.next();
            
            if(resultado.getRow() == 1){
                horarioRecuperada.setCodigo(resultado.getInt("CODIGO"));
                horarioRecuperada.setInicio_rotina(resultado.getString("INICIO_ROTINA"));
                horarioRecuperada.setTermino_rotina(resultado.getString("TERMINO_ROTINA"));
                horarioRecuperada.setHorarios(resultado.getString("HORARIOS"));
                horarioRecuperada.setAtividade_horarios(resultado.getString("ATIVIDADE_HORARIOS"));
                horarioRecuperada.setTurno(resultado.getString("TURNO"));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar horario: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Recuperar Horario: " + e.getMessage());
            }
        }   
        
        return horarioRecuperada;
    }
    
    public static ArrayList<Horario>RecuperaObjetos(String pCampo, String pValor){
        Connection conexao = FabricaConexao.getConnection();
        
        ArrayList<Horario> horarios = new ArrayList<>();
        
        Statement consulta = null;
        ResultSet resultado = null;
        
        String sql = "select * from HORARIO where "+ pCampo + " like '%"+ pValor + "%'";
        
        
        
        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            while (resultado.next()){
                Horario horarioTemp = new Horario();
                horarioTemp.setCodigo(resultado.getInt("CODIGO"));
                horarioTemp.setHorarios(resultado.getString("HORARIOS"));
                horarioTemp.setAtividade_horarios(resultado.getString("ATIVIDADE_HORARIOS"));
                horarios.add(horarioTemp);
                
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar horarios: " + e.getMessage()+ "\n" + sql);
        }finally{
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função RecuperarObjeto(): " + e.getMessage());
            }
        }
        return horarios;
    }
    
}
