/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Avaliacoes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Murilo
 */
public class AvaliacoesDAO {
    
    public static final int cNavPrimeiro = 0;
    public static final int cNavAnterior = 1;
    public static final int cNavProximo = 2;
    public static final int cNavUltimo = 3;
    

    public static int PegaCodigoPelaNavegacao(int iOpcao, int iCodigoAtual){
        Connection conexao = FabricaConexao.getConnection();
        
        Statement consulta = null;
        ResultSet resultado = null;        
        int codigoEncontrado = -1;
        
        String sql = "";
        
        switch (iOpcao) {
            case cNavPrimeiro: sql = "select min(CODIGO) as CODIGO from AVALIACOES"; break;
            case cNavAnterior: sql = "select max(CODIGO) as CODIGO from AVALIACOES where CODIGO < "+ String.valueOf(iCodigoAtual); break;
            case cNavProximo: sql = "select min(CODIGO) as CODIGO from AVALIACOES where CODIGO > "+ String.valueOf(iCodigoAtual); break;
            case cNavUltimo: sql = "select max(CODIGO) as CODIGO from AVALIACOES"; break;
        }
        
        try {
            consulta = (Statement)conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigoEncontrado = resultado.getInt("CODIGO");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        }finally{
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função PegaCodigoPelaNavegação: " + e.getMessage());
            }
        }
        return codigoEncontrado;
    }

    public static int ProximoCodigo() {
        Connection conexao = FabricaConexao.getConnection();

        Statement consulta = null;
        ResultSet resultado = null;
        int codigo = -1;

        String sql = "select max(codigo) as CODIGO from AVALIACOES";

        try {
            consulta = (Statement) conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigo = resultado.getInt("CODIGO");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Próximo Código: " + e.getMessage());
            }
        }

        return codigo + 1;
    }

    public static void Salvar(Avaliacoes avaliacoes) {
        Connection conexao = FabricaConexao.getConnection();

        PreparedStatement insereSt = null;

        String sql = "insert avaliacoes (CODIGO, DATA_AVALIACOES, NOME_MATERIA, TIPO_ATIVIDADE) values (?,?,?,?)";

        try {

            insereSt = conexao.prepareStatement(sql);
            insereSt.setInt(1, avaliacoes.getCodigo());
            insereSt.setString(2, avaliacoes.getData_avaliacoes());
            insereSt.setString(3, avaliacoes.getNome_materia());
            insereSt.setString(4, avaliacoes.getTipo_atividade());
            insereSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir avaliacoes: " + e.getMessage());
        } finally {
            try {
                JOptionPane.showMessageDialog(null, "Avaliacoes incluída com sucesso: ");
                insereSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Salvar(): " + e.getMessage());
            }
        }
    }
    
    public static void Atualizar(Avaliacoes avaliacoes){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement atualizaSt = null;
        
        String sql = "update avaliacoes set data_avaliacoes = ?, nome_materia = ?, tipo_atividade = ? where codigo = ?";
        
        try {
            atualizaSt = conexao.prepareStatement(sql);
            atualizaSt.setString(1, avaliacoes.getData_avaliacoes());
            atualizaSt.setString(2, avaliacoes.getNome_materia());
            atualizaSt.setString(3, avaliacoes.getTipo_atividade());
            atualizaSt.setInt(4, avaliacoes.getCodigo());
            atualizaSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar avaliacoes: " + e.getMessage());
        }finally{
            try {
                atualizaSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Atualizar(): " + e.getMessage());
            }
        }    
    }
    
    public static void Excluir(int iCod){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement excluiSt = null;
        
        String sql = "delete from avaliacoes where codigo = "+iCod;
        
        try {
            excluiSt = conexao.prepareStatement(sql);
            excluiSt.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir avaliacoes: " + e.getMessage());
        }finally{
           try {
                excluiSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Excluir(): " + e.getMessage());
            } 
        }
    }

    public static Avaliacoes RecuperarAvaliacoes(int iCod) {
        Connection conexao = FabricaConexao.getConnection();

        Avaliacoes avaliacoesRecuperada = new Avaliacoes();
        Statement consulta = null;
        ResultSet resultado = null;

        String sql = "select * from avaliacoes where codigo = " + iCod;

        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            resultado.next();
            
            if(resultado.getRow() == 1){
                avaliacoesRecuperada.setCodigo(resultado.getInt("CODIGO"));
                avaliacoesRecuperada.setData_avaliacoes(resultado.getString("DATA_AVALIACOES"));
                avaliacoesRecuperada.setNome_materia(resultado.getString("NOME_MATERIA"));
                avaliacoesRecuperada.setTipo_atividade(resultado.getString("TIPO_ATIVIDADE"));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar avaliacoes: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Recuperar Avaliacoes: " + e.getMessage());
            }
        }   
        
        return avaliacoesRecuperada;
    }
    
    public static ArrayList<Avaliacoes>RecuperaObjetos(String pCampo, String pValor){
        Connection conexao = FabricaConexao.getConnection();
        
        ArrayList<Avaliacoes> avaliacoess = new ArrayList<>();
        
        Statement consulta = null;
        ResultSet resultado = null;
        
        String sql = "select * from AVALIACOES where "+ pCampo + " like '%"+ pValor + "%'";
        
        
        
        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            while (resultado.next()){
                Avaliacoes avaliacoesTemp = new Avaliacoes();
                avaliacoesTemp.setCodigo(resultado.getInt("CODIGO"));
                avaliacoesTemp.setData_avaliacoes(resultado.getString("DATA_AVALIACOES"));
                avaliacoesTemp.setNome_materia(resultado.getString("NOME_MATERIA"));
                avaliacoesTemp.setTipo_atividade(resultado.getString("TIPO_ATIVIDADE"));
                avaliacoess.add(avaliacoesTemp);
                
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar avaliacoess: " + e.getMessage()+ "\n" + sql);
        }finally{
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função RecuperarObjeto(): " + e.getMessage());
            }
        }
        return avaliacoess;
    }
}
