/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import DAO.MateriaDAO;
import java.util.ArrayList;

/**
 *
 * @author Murilo
 */
public class Materia {
    
    private int codigo;
    private String materias;
    private String atividades_extras;

    public Materia(){
        this.codigo = -1;
        this.materias = "";
        this.atividades_extras = "";
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getMaterias() {
        return materias;
    }

    public void setMaterias(String materias) {
        this.materias = materias;
    }

    public String getAtividades_extras() {
        return atividades_extras;
    }

    public void setAtividades_extras(String atividades_extras) {
        this.atividades_extras = atividades_extras;
    }
    
    public void setProximoCodigo(){
        this.codigo = MateriaDAO. ProximoCodigo();
    }
    
    public void Salvar(){
        MateriaDAO.Salvar(this);
    }
    
    public void Excluir(int Chave){
        MateriaDAO.Excluir(Chave);
    }
    
    public void Atualizar(){
        MateriaDAO.Atualizar(this);
    }
    
    public void RecuperarObjeto(int Codigo){
        Materia materiaTemp = MateriaDAO.RecuperarMateria(Codigo);
        this.setCodigo(materiaTemp.getCodigo());
        this.setMaterias(materiaTemp.getMaterias());
        this.setAtividades_extras(materiaTemp.getAtividades_extras());
    }
    
    public void RecuperaObjetoPelaNavegacao(int Opcao, int CodigoAtual){
        int CodigoNav = MateriaDAO.PegaCodigoPelaNavegacao(Opcao, CodigoAtual);
        RecuperarObjeto(CodigoNav);
    }
    
    public ArrayList<Materia> RecuperaObjetos (String pCampo, String pValor){
        
        String NomeCampo = "";
        
        if (pCampo.equalsIgnoreCase("Código")){
            NomeCampo = "CODIGO";
        } else if (pCampo.equalsIgnoreCase("Matérias")){
            NomeCampo = "MATERIAS";
        } else if (pCampo.equalsIgnoreCase("Atividades Extras")){
            NomeCampo = "ATIVIDADES_EXTRAS";
        }
        
        return MateriaDAO.RecuperaObjetos(NomeCampo, pValor);
    }
}
