/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Atendimento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Murilo
 */
public class AtendimentoDAO {
    
    public static final int cNavPrimeiro = 0;
    public static final int cNavAnterior = 1;
    public static final int cNavProximo = 2;
    public static final int cNavUltimo = 3;
    

    public static int PegaCodigoPelaNavegacao(int iOpcao, int iCodigoAtual){
        Connection conexao = FabricaConexao.getConnection();
        
        Statement consulta = null;
        ResultSet resultado = null;        
        int codigoEncontrado = -1;
        
        String sql = "";
        
        switch (iOpcao) {
            case cNavPrimeiro: sql = "select min(CODIGO) as CODIGO from ATENDIMENTO"; break;
            case cNavAnterior: sql = "select max(CODIGO) as CODIGO from ATENDIMENTO where CODIGO < "+ String.valueOf(iCodigoAtual); break;
            case cNavProximo: sql = "select min(CODIGO) as CODIGO from ATENDIMENTO where CODIGO > "+ String.valueOf(iCodigoAtual); break;
            case cNavUltimo: sql = "select max(CODIGO) as CODIGO from ATENDIMENTO"; break;
        }
        
        try {
            consulta = (Statement)conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigoEncontrado = resultado.getInt("CODIGO");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        }finally{
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função PegaCodigoPelaNavegação: " + e.getMessage());
            }
        }
        return codigoEncontrado;
    }

    public static int ProximoCodigo() {
        Connection conexao = FabricaConexao.getConnection();

        Statement consulta = null;
        ResultSet resultado = null;
        int codigo = -1;

        String sql = "select max(codigo) as CODIGO from ATENDIMENTO";

        try {
            consulta = (Statement) conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigo = resultado.getInt("CODIGO");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Próximo Código: " + e.getMessage());
            }
        }

        return codigo + 1;
    }

    public static void Salvar(Atendimento atendimento) {
        Connection conexao = FabricaConexao.getConnection();

        PreparedStatement insereSt = null;

        String sql = "insert atendimento (CODIGO, HORARIOS, PROFESSOR, MATERIA) values (?,?,?,?)";

        try {

            insereSt = conexao.prepareStatement(sql);
            insereSt.setInt(1, atendimento.getCodigo());
            insereSt.setString(2, atendimento.getHorarios());
            insereSt.setString(3, atendimento.getProfessor());
            insereSt.setString(4, atendimento.getMateria());
            insereSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir atendimento: " + e.getMessage());
        } finally {
            try {
                JOptionPane.showMessageDialog(null, "Atendimento incluída com sucesso: ");
                insereSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Salvar(): " + e.getMessage());
            }
        }
    }
    
    public static void Atualizar(Atendimento atendimento){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement atualizaSt = null;
        
        String sql = "update atendimento set horarios = ?, professor = ?, materia = ? where codigo = ?";
        
        try {
            atualizaSt = conexao.prepareStatement(sql);
            atualizaSt.setString(1, atendimento.getHorarios());
            atualizaSt.setString(2, atendimento.getProfessor());
            atualizaSt.setString(3, atendimento.getMateria());
            atualizaSt.setInt(4, atendimento.getCodigo());
            atualizaSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar atendimento: " + e.getMessage());
        }finally{
            try {
                atualizaSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Atualizar(): " + e.getMessage());
            }
        }    
    }
    
    public static void Excluir(int iCod){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement excluiSt = null;
        
        String sql = "delete from atendimento where codigo = "+iCod;
        
        try {
            excluiSt = conexao.prepareStatement(sql);
            excluiSt.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir atendimento: " + e.getMessage());
        }finally{
           try {
                excluiSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Excluir(): " + e.getMessage());
            } 
        }
    }

    public static Atendimento RecuperarAtendimento(int iCod) {
        Connection conexao = FabricaConexao.getConnection();

        Atendimento atendimentoRecuperada = new Atendimento();
        Statement consulta = null;
        ResultSet resultado = null;

        String sql = "select * from atendimento where codigo = " + iCod;

        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            resultado.next();
            
            if(resultado.getRow() == 1){
                atendimentoRecuperada.setCodigo(resultado.getInt("CODIGO"));
                atendimentoRecuperada.setHorarios(resultado.getString("HORARIOS"));
                atendimentoRecuperada.setProfessor(resultado.getString("PROFESSOR"));
                atendimentoRecuperada.setMateria(resultado.getString("MATERIA"));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar atendimento: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Recuperar Atendimento: " + e.getMessage());
            }
        }   
        
        return atendimentoRecuperada;
    }
    
    public static ArrayList<Atendimento>RecuperaObjetos(String pCampo, String pValor){
        Connection conexao = FabricaConexao.getConnection();
        
        ArrayList<Atendimento> atendimentos = new ArrayList<>();
        
        Statement consulta = null;
        ResultSet resultado = null;
        
        String sql = "select * from ATENDIMENTO where "+ pCampo + " like '%"+ pValor + "%'";
        
        
        
        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            while (resultado.next()){
                Atendimento atendimentoTemp = new Atendimento();
                atendimentoTemp.setCodigo(resultado.getInt("CODIGO"));
                atendimentoTemp.setHorarios(resultado.getString("HORARIOS"));
                atendimentoTemp.setProfessor(resultado.getString("PROFESSOR"));
                atendimentoTemp.setMateria(resultado.getString("MATERIA"));
                atendimentos.add(atendimentoTemp);
                
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar atendimentos: " + e.getMessage()+ "\n" + sql);
        }finally{
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função RecuperarObjeto(): " + e.getMessage());
            }
        }
        return atendimentos;
    }
}
