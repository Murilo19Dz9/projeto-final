/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import Modelo.Pessoa;
import java.sql.PreparedStatement;
import java.util.ArrayList;

/**
 *
 * @author Murilo
 */
    public class PessoaDAO {
    
    public static final int cNavPrimeiro = 0;
    public static final int cNavAnterior = 1;
    public static final int cNavProximo = 2;
    public static final int cNavUltimo = 3;
    

    public static int PegaCodigoPelaNavegacao(int iOpcao, int iCodigoAtual){
        Connection conexao = FabricaConexao.getConnection();
        
        Statement consulta = null;
        ResultSet resultado = null;        
        int codigoEncontrado = -1;
        
        String sql = "";
        
        switch (iOpcao) {
            case cNavPrimeiro: sql = "select min(CODIGO) as CODIGO from PESSOA"; break;
            case cNavAnterior: sql = "select max(CODIGO) as CODIGO from PESSOA where CODIGO < "+ String.valueOf(iCodigoAtual); break;
            case cNavProximo: sql = "select min(CODIGO) as CODIGO from PESSOA where CODIGO > "+ String.valueOf(iCodigoAtual); break;
            case cNavUltimo: sql = "select max(CODIGO) as CODIGO from PESSOA"; break;
        }
        
        try {
            consulta = (Statement)conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigoEncontrado = resultado.getInt("CODIGO");
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        }finally{
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função PegaCodigoPelaNavegação: " + e.getMessage());
            }
        }
        return codigoEncontrado;
    }

    public static int ProximoCodigo() {
        Connection conexao = FabricaConexao.getConnection();

        Statement consulta = null;
        ResultSet resultado = null;
        int codigo = -1;

        String sql = "select max(codigo) as CODIGO from PESSOA";

        try {
            consulta = (Statement) conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            resultado.next();
            codigo = resultado.getInt("CODIGO");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao executar SQL de navegação: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Próximo Código: " + e.getMessage());
            }
        }

        return codigo + 1;
    }

    public static void Salvar(Pessoa pessoa) {
        Connection conexao = FabricaConexao.getConnection();

        PreparedStatement insereSt = null;

        String sql = "insert pessoa (CODIGO, NOME, CPF, TELEFONE, ENDERECO, IDADE, EMAIL, ESCOLA, USUARIO, SENHA) values (?,?,?,?,?,?,?,?,?,?)";

        try {

            insereSt = conexao.prepareStatement(sql);
            insereSt.setInt(1, pessoa.getCodigo());
            insereSt.setString(2, pessoa.getNome());
            insereSt.setString(3, pessoa.getCpf());
            insereSt.setString(4, pessoa.getTelefone());
            insereSt.setString(5, pessoa.getEndereco());
            insereSt.setString(6, pessoa.getIdade());
            insereSt.setString(7, pessoa.getEmail());
            insereSt.setString(8, pessoa.getEscola());
            insereSt.setString(9, pessoa.getUsuario());
            insereSt.setString(10, pessoa.getSenha());
            insereSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao incluir pessoa: " + e.getMessage());
        } finally {
            try {
                JOptionPane.showMessageDialog(null, "Pessoa incluída com sucesso: ");
                insereSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Salvar(): " + e.getMessage());
            }
        }
    }
    
    public static void Atualizar(Pessoa pessoa){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement atualizaSt = null;
        
        String sql = "update pessoa set nome = ?, cpf = ?, telefone = ?, endereco = ?, idade = ?, email = ?, escola = ?, usuario = ?, senha = ? where codigo = ?";
        
        try {
            atualizaSt = conexao.prepareStatement(sql);
            atualizaSt.setString(1, pessoa.getNome());
            atualizaSt.setString(2, pessoa.getCpf());
            atualizaSt.setString(3, pessoa.getTelefone());
            atualizaSt.setString(4, pessoa.getEndereco());
            atualizaSt.setString(5, pessoa.getIdade());
            atualizaSt.setString(6, pessoa.getEmail());
            atualizaSt.setString(7, pessoa.getEscola());
            atualizaSt.setString(8, pessoa.getUsuario());
            atualizaSt.setString(9, pessoa.getSenha());
            atualizaSt.setInt(10, pessoa.getCodigo());
            atualizaSt.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar pessoa: " + e.getMessage());
        }finally{
            try {
                atualizaSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Atualizar(): " + e.getMessage());
            }
        }    
    }
    
    public static void Excluir(int iCod){
        Connection conexao = FabricaConexao.getConnection();
        
        PreparedStatement excluiSt = null;
        
        String sql = "delete from pessoa where codigo = "+iCod;
        
        try {
            excluiSt = conexao.prepareStatement(sql);
            excluiSt.executeUpdate();
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir pessoa: " + e.getMessage());
        }finally{
           try {
                excluiSt.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Excluir(): " + e.getMessage());
            } 
        }
    }

    public static Pessoa RecuperarPessoa(int iCod) {
        Connection conexao = FabricaConexao.getConnection();

        Pessoa pessoaRecuperada = new Pessoa();
        Statement consulta = null;
        ResultSet resultado = null;

        String sql = "select * from pessoa where codigo = " + iCod;

        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            resultado.next();
            
            if(resultado.getRow() == 1){
                pessoaRecuperada.setCodigo(resultado.getInt("CODIGO"));
                pessoaRecuperada.setNome(resultado.getString("NOME"));
                pessoaRecuperada.setCpf(resultado.getString("CPF"));
                pessoaRecuperada.setTelefone(resultado.getString("TELEFONE"));
                pessoaRecuperada.setEndereco(resultado.getString("ENDERECO"));
                pessoaRecuperada.setIdade(resultado.getString("IDADE"));
                pessoaRecuperada.setEmail(resultado.getString("EMAIL"));
                pessoaRecuperada.setEscola(resultado.getString("ESCOLA"));
                pessoaRecuperada.setUsuario(resultado.getString("USUARIO"));
                pessoaRecuperada.setSenha(resultado.getString("SENHA"));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar pessoa: " + e.getMessage());
        } finally {
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função Recuperar Pessoa: " + e.getMessage());
            }
        }   
        
        return pessoaRecuperada;
    }
    
    public static ArrayList<Pessoa>RecuperaObjetos(String pCampo, String pValor){
        Connection conexao = FabricaConexao.getConnection();
        
        ArrayList<Pessoa> pessoas = new ArrayList<>();
        
        Statement consulta = null;
        ResultSet resultado = null;
        
        String sql = "select * from PESSOA where "+ pCampo + " like '%"+ pValor + "%'";
        
        
        
        try {
            consulta = conexao.createStatement();
            resultado = consulta.executeQuery(sql);
            
            while (resultado.next()){
                Pessoa pessoaTemp = new Pessoa();
                pessoaTemp.setCodigo(resultado.getInt("CODIGO"));
                pessoaTemp.setNome(resultado.getString("NOME"));
                pessoaTemp.setCpf(resultado.getString("CPF"));
                pessoaTemp.setEmail(resultado.getString("EMAIL"));
                pessoas.add(pessoaTemp);
                
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao recuperar pessoas: " + e.getMessage()+ "\n" + sql);
        }finally{
            try {
                consulta.close();
                resultado.close();
                conexao.close();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Erro ao encerrar conexão na função RecuperarObjeto(): " + e.getMessage());
            }
        }
        return pessoas;
    }
}
