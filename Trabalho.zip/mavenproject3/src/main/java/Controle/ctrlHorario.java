/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

import Modelo.Horario;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Murilo
 */
public class ctrlHorario {
    
    private final Horario objHorario;
    
    public ctrlHorario(){
        this.objHorario = new Horario();
    }
    
    public int Salvar(ArrayList<String> pLista){
        this.objHorario.setInicio_rotina(pLista.get(1));
        this.objHorario.setTermino_rotina(pLista.get(2));
        this.objHorario.setHorarios(pLista.get(3));
        this.objHorario.setAtividade_horarios(pLista.get(4));
        this.objHorario.setTurno(pLista.get(5));
        this.objHorario.setProximoCodigo();
        this.objHorario.Salvar();
        return this.objHorario.getCodigo();
    }
    
    public void Excluir (int Chave){
        this.objHorario.setCodigo(Chave);
        this.objHorario.Excluir(Chave);
    }
    
    public void Atualizar (ArrayList<String> pLista){
        this.objHorario.setCodigo(Integer.valueOf(pLista.get(0)));
        this.objHorario.setInicio_rotina(pLista.get(1));
        this.objHorario.setTermino_rotina(pLista.get(2));
        this.objHorario.setHorarios(pLista.get(3));
        this.objHorario.setAtividade_horarios(pLista.get(4));
        this.objHorario.setTurno(pLista.get(5));
        
        this.objHorario.Atualizar();
        
    }
    
    public ArrayList<String> ConverterObjetoParaArray(){
        ArrayList<String>vetCampos = new ArrayList<>();
        vetCampos.add(String.valueOf(this.objHorario.getCodigo()));
        vetCampos.add(this.objHorario.getInicio_rotina());
        vetCampos.add(this.objHorario.getTermino_rotina());
        vetCampos.add(this.objHorario.getHorarios());
        vetCampos.add(this.objHorario.getAtividade_horarios());
        vetCampos.add(this.objHorario.getTurno());
        
        return vetCampos;
    }
    
    public ArrayList<String> RecuperaObjeto(int Codigo){
        this.objHorario.RecuperarObjeto(Codigo);
        return ConverterObjetoParaArray();
    }
    
    public ArrayList<String>RecuperaObjetoNavegacao (int Opcao, int Codigo){
        this.objHorario.RecuperaObjetoPelaNavegacao(Opcao, Codigo);
        return ConverterObjetoParaArray();
    }
    
    public DefaultTableModel PesquisaObjeto (ArrayList<String> Parametros, DefaultTableModel ModeloTabela){
        String Campo = Parametros.get(0);
        String Valor = Parametros.get(1);
        
        ArrayList<Horario> Horarios = this.objHorario.RecuperaObjetos(Campo, Valor);
        
        Vector<String> vetVetor;
        Horario objHorarioBuffer;    
        
        for (int i = 0; i < Horarios.size(); i++) {
            vetVetor = new Vector<>();
            objHorarioBuffer = Horarios.get(i);
            
            vetVetor.addElement(String.valueOf(objHorarioBuffer.getCodigo()));
            vetVetor.addElement(objHorarioBuffer.getHorarios());
            vetVetor.addElement(objHorarioBuffer.getAtividade_horarios());
            ModeloTabela.addRow(vetVetor);        
        }
        return ModeloTabela;
    }
    
}
