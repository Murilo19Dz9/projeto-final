/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

import Modelo.Atendimento;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Murilo
 */
public class ctrlAtendimento {
    
    private final Atendimento objAtendimento;
    
    public ctrlAtendimento(){
        this.objAtendimento = new Atendimento();
    }
    
    public int Salvar(ArrayList<String> pLista){
        this.objAtendimento.setHorarios(pLista.get(1));
        this.objAtendimento.setProfessor(pLista.get(2));
        this.objAtendimento.setMateria(pLista.get(3));
        this.objAtendimento.setProximoCodigo();
        this.objAtendimento.Salvar();
        return this.objAtendimento.getCodigo();
    }
    
    public void Excluir (int Chave){
        this.objAtendimento.setCodigo(Chave);
        this.objAtendimento.Excluir(Chave);
    }
    
    public void Atualizar (ArrayList<String> pLista){
        this.objAtendimento.setCodigo(Integer.valueOf(pLista.get(0)));
        this.objAtendimento.setHorarios(pLista.get(1));
        this.objAtendimento.setProfessor(pLista.get(2));
        this.objAtendimento.setMateria(pLista.get(3));
        
        this.objAtendimento.Atualizar();
        
    }
    
    public ArrayList<String> ConverterObjetoParaArray(){
        ArrayList<String>vetCampos = new ArrayList<>();
        vetCampos.add(String.valueOf(this.objAtendimento.getCodigo()));
        vetCampos.add(this.objAtendimento.getHorarios());
        vetCampos.add(this.objAtendimento.getProfessor());
        vetCampos.add(this.objAtendimento.getMateria());
        
        return vetCampos;
    }
    
    public ArrayList<String> RecuperaObjeto(int Codigo){
        this.objAtendimento.RecuperarObjeto(Codigo);
        return ConverterObjetoParaArray();
    }
    
    public ArrayList<String>RecuperaObjetoNavegacao (int Opcao, int Codigo){
        this.objAtendimento.RecuperaObjetoPelaNavegacao(Opcao, Codigo);
        return ConverterObjetoParaArray();
    }
    
    public DefaultTableModel PesquisaObjeto (ArrayList<String> Parametros, DefaultTableModel ModeloTabela){
        String Campo = Parametros.get(0);
        String Valor = Parametros.get(1);
        
        ArrayList<Atendimento> Atendimentos = this.objAtendimento.RecuperaObjetos(Campo, Valor);
        
        Vector<String> vetVetor;
        Atendimento objAtendimentoBuffer;    
        
        for (int i = 0; i < Atendimentos.size(); i++) {
            vetVetor = new Vector<>();
            objAtendimentoBuffer = Atendimentos.get(i);
            
            vetVetor.addElement(String.valueOf(objAtendimentoBuffer.getCodigo()));
            vetVetor.addElement(objAtendimentoBuffer.getHorarios());
            vetVetor.addElement(objAtendimentoBuffer.getProfessor());
            vetVetor.addElement(objAtendimentoBuffer.getMateria());
            ModeloTabela.addRow(vetVetor);        
        }
        return ModeloTabela;
    }
}
