/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

import Modelo.Pessoa;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Murilo
 */
public class ctrlPessoa {
    
    private final Pessoa objPessoa;
    
    public ctrlPessoa(){
        this.objPessoa = new Pessoa();
    }
    
    public int Salvar(ArrayList<String> pLista){
        this.objPessoa.setNome(pLista.get(1));
        this.objPessoa.setCpf(pLista.get(2));
        this.objPessoa.setTelefone(pLista.get(3));
        this.objPessoa.setEndereco(pLista.get(4));
        this.objPessoa.setIdade(pLista.get(5));
        this.objPessoa.setEmail(pLista.get(6));
        this.objPessoa.setEscola(pLista.get(7));
        this.objPessoa.setUsuario(pLista.get(8));
        this.objPessoa.setSenha(pLista.get(9));
        this.objPessoa.setProximoCodigo();
        this.objPessoa.Salvar();
        return this.objPessoa.getCodigo();
    }
    
    public void Excluir (int Chave){
        this.objPessoa.setCodigo(Chave);
        this.objPessoa.Excluir(Chave);
    }
    
    public void Atualizar (ArrayList<String> pLista){
        this.objPessoa.setCodigo(Integer.valueOf(pLista.get(0)));
        this.objPessoa.setNome(pLista.get(1));
        this.objPessoa.setCpf(pLista.get(2));
        this.objPessoa.setTelefone(pLista.get(3));
        this.objPessoa.setEndereco(pLista.get(4));
        this.objPessoa.setIdade(pLista.get(5));
        this.objPessoa.setEmail(pLista.get(6));
        this.objPessoa.setEscola(pLista.get(7));
        this.objPessoa.setUsuario(pLista.get(8));
        this.objPessoa.setSenha(pLista.get(9));
        
        this.objPessoa.Atualizar();
        
    }
    
    public ArrayList<String> ConverterObjetoParaArray(){
        ArrayList<String>vetCampos = new ArrayList<>();
        vetCampos.add(String.valueOf(this.objPessoa.getCodigo()));
        vetCampos.add(this.objPessoa.getNome());
        vetCampos.add(this.objPessoa.getCpf());
        vetCampos.add(this.objPessoa.getTelefone());
        vetCampos.add(this.objPessoa.getEndereco());
        vetCampos.add(this.objPessoa.getIdade());
        vetCampos.add(this.objPessoa.getEmail());
        vetCampos.add(this.objPessoa.getEscola());
        vetCampos.add(this.objPessoa.getUsuario());
        vetCampos.add(this.objPessoa.getSenha());
        
        return vetCampos;
    }
    
    public ArrayList<String> RecuperaObjeto(int Codigo){
        this.objPessoa.RecuperarObjeto(Codigo);
        return ConverterObjetoParaArray();
    }
    
    public ArrayList<String>RecuperaObjetoNavegacao (int Opcao, int Codigo){
        this.objPessoa.RecuperaObjetoPelaNavegacao(Opcao, Codigo);
        return ConverterObjetoParaArray();
    }
    
    public DefaultTableModel PesquisaObjeto (ArrayList<String> Parametros, DefaultTableModel ModeloTabela){
        String Campo = Parametros.get(0);
        String Valor = Parametros.get(1);
        
        ArrayList<Pessoa> Pessoas = this.objPessoa.RecuperaObjetos(Campo, Valor);
        
        Vector<String> vetVetor;
        Pessoa objPessoaBuffer;    
        
        for (int i = 0; i < Pessoas.size(); i++) {
            vetVetor = new Vector<>();
            objPessoaBuffer = Pessoas.get(i);
            
            vetVetor.addElement(String.valueOf(objPessoaBuffer.getCodigo()));
            vetVetor.addElement(objPessoaBuffer.getNome());
            vetVetor.addElement(objPessoaBuffer.getCpf());
            vetVetor.addElement(objPessoaBuffer.getEmail());
            ModeloTabela.addRow(vetVetor);        
        }
        return ModeloTabela;
    }
}
