/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controle;

import Modelo.Materia;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Murilo
 */
public class ctrlMateria {
    
    private final Materia objMateria;
    
    public ctrlMateria(){
        this.objMateria = new Materia();
    }
    
    public int Salvar(ArrayList<String> pLista){
        this.objMateria.setMaterias(pLista.get(1));
        this.objMateria.setAtividades_extras(pLista.get(2));
        this.objMateria.setProximoCodigo();
        this.objMateria.Salvar();
        return this.objMateria.getCodigo();
    }
    
    public void Excluir (int Chave){
        this.objMateria.setCodigo(Chave);
        this.objMateria.Excluir(Chave);
    }
    
    public void Atualizar (ArrayList<String> pLista){
        this.objMateria.setCodigo(Integer.valueOf(pLista.get(0)));
        this.objMateria.setMaterias(pLista.get(1));
        this.objMateria.setAtividades_extras(pLista.get(2));
        
        this.objMateria.Atualizar();
        
    }
    
    public ArrayList<String> ConverterObjetoParaArray(){
        ArrayList<String>vetCampos = new ArrayList<>();
        vetCampos.add(String.valueOf(this.objMateria.getCodigo()));
        vetCampos.add(this.objMateria.getMaterias());
        vetCampos.add(this.objMateria.getAtividades_extras());
        
        return vetCampos;
    }
    
    public ArrayList<String> RecuperaObjeto(int Codigo){
        this.objMateria.RecuperarObjeto(Codigo);
        return ConverterObjetoParaArray();
    }
    
    public ArrayList<String>RecuperaObjetoNavegacao (int Opcao, int Codigo){
        this.objMateria.RecuperaObjetoPelaNavegacao(Opcao, Codigo);
        return ConverterObjetoParaArray();
    }
    
    public DefaultTableModel PesquisaObjeto (ArrayList<String> Parametros, DefaultTableModel ModeloTabela){
        String Campo = Parametros.get(0);
        String Valor = Parametros.get(1);
        
        ArrayList<Materia> Materias = this.objMateria.RecuperaObjetos(Campo, Valor);
        
        Vector<String> vetVetor;
        Materia objMateriaBuffer;    
        
        for (int i = 0; i < Materias.size(); i++) {
            vetVetor = new Vector<>();
            objMateriaBuffer = Materias.get(i);
            
            vetVetor.addElement(String.valueOf(objMateriaBuffer.getCodigo()));
            vetVetor.addElement(objMateriaBuffer.getMaterias());
            vetVetor.addElement(objMateriaBuffer.getAtividades_extras());
            ModeloTabela.addRow(vetVetor);        
        }
        return ModeloTabela;
    }
}
