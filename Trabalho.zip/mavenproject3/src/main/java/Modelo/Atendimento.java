/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import DAO.AtendimentoDAO;
import java.util.ArrayList;

/**
 *
 * @author Murilo
 */
public class Atendimento {
    
    private int codigo;
    private String horarios;
    private String professor;
    private String materia;
    
    public Atendimento(){
        this.codigo = -1;
        this.horarios = "";
        this.professor = "";
        this.materia = "";
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getHorarios() {
        return horarios;
    }

    public void setHorarios(String horarios) {
        this.horarios = horarios;
    }

    public String getProfessor() {
        return professor;
    }

    public void setProfessor(String professor) {
        this.professor = professor;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }
    
    public void setProximoCodigo(){
        this.codigo = AtendimentoDAO. ProximoCodigo();
    }
    
    public void Salvar(){
        AtendimentoDAO.Salvar(this);
    }
    
    public void Excluir(int Chave){
        AtendimentoDAO.Excluir(Chave);
    }
    
    public void Atualizar(){
        AtendimentoDAO.Atualizar(this);
    }
    
    public void RecuperarObjeto(int Codigo){
        Atendimento atendimentoTemp = AtendimentoDAO.RecuperarAtendimento(Codigo);
        this.setCodigo(atendimentoTemp.getCodigo());
        this.setHorarios(atendimentoTemp.getHorarios());
        this.setProfessor(atendimentoTemp.getProfessor());
        this.setMateria(atendimentoTemp.getMateria());
    }
    
    public void RecuperaObjetoPelaNavegacao(int Opcao, int CodigoAtual){
        int CodigoNav = AtendimentoDAO.PegaCodigoPelaNavegacao(Opcao, CodigoAtual);
        RecuperarObjeto(CodigoNav);
    }
    
    public ArrayList<Atendimento> RecuperaObjetos (String pCampo, String pValor){
        
        String NomeCampo = "";
        
        if (pCampo.equalsIgnoreCase("Código")){
            NomeCampo = "CODIGO";
        } else if (pCampo.equalsIgnoreCase("Horário")){
            NomeCampo = "HORARIOS";
        } else if (pCampo.equalsIgnoreCase("Professor")){
            NomeCampo = "PROFESSOR";
        } else if (pCampo.equalsIgnoreCase("Matéria")){
            NomeCampo = "MATERIA";
        }
        
        return AtendimentoDAO.RecuperaObjetos(NomeCampo, pValor);
    }
}
