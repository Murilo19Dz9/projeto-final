/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import DAO.HorarioDAO;
import java.util.ArrayList;

/**
 *
 * @author Murilo
 */
public class Horario {
    
    private int codigo;
    private String inicio_rotina;
    private String termino_rotina;
    private String horarios;
    private String atividade_horarios;
    private String turno;

    public Horario(){
        this.codigo = -1;
        this.inicio_rotina = "";
        this.termino_rotina = "";
        this.horarios = "";
        this.atividade_horarios = "";
        this.turno = "";
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getInicio_rotina() {
        return inicio_rotina;
    }

    public void setInicio_rotina(String inicio_rotina) {
        this.inicio_rotina = inicio_rotina;
    }

    public String getTermino_rotina() {
        return termino_rotina;
    }

    public void setTermino_rotina(String termino_rotina) {
        this.termino_rotina = termino_rotina;
    }

    public String getHorarios() {
        return horarios;
    }

    public void setHorarios(String horarios) {
        this.horarios = horarios;
    }

    public String getAtividade_horarios() {
        return atividade_horarios;
    }

    public void setAtividade_horarios(String atividade_horarios) {
        this.atividade_horarios = atividade_horarios;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }
    
    public void setProximoCodigo(){
        this.codigo = HorarioDAO. ProximoCodigo();
    }
    
    public void Salvar(){
        HorarioDAO.Salvar(this);
    }
    
    public void Excluir(int Chave){
        HorarioDAO.Excluir(Chave);
    }
    
    public void Atualizar(){
        HorarioDAO.Atualizar(this);
    }
    
    public void RecuperarObjeto(int Codigo){
        Horario horarioTemp = HorarioDAO.RecuperarHorario(Codigo);
        this.setCodigo(horarioTemp.getCodigo());
        this.setInicio_rotina(horarioTemp.getInicio_rotina());
        this.setTermino_rotina(horarioTemp.getTermino_rotina());
        this.setHorarios(horarioTemp.getHorarios());
        this.setAtividade_horarios(horarioTemp.getAtividade_horarios());
        this.setTurno(horarioTemp.getTurno());
    }
    
    public void RecuperaObjetoPelaNavegacao(int Opcao, int CodigoAtual){
        int CodigoNav = HorarioDAO.PegaCodigoPelaNavegacao(Opcao, CodigoAtual);
        RecuperarObjeto(CodigoNav);
    }
    
    public ArrayList<Horario> RecuperaObjetos (String pCampo, String pValor){
        
        String NomeCampo = "";
        
        if (pCampo.equalsIgnoreCase("Código")){
            NomeCampo = "CODIGO";
        } else if (pCampo.equalsIgnoreCase("Horários")){
            NomeCampo = "HORARIOS";
        } else if (pCampo.equalsIgnoreCase("Atividades no Horário")){
            NomeCampo = "ATIVIDADE_HORARIOS";
        }
        
        return HorarioDAO.RecuperaObjetos(NomeCampo, pValor);
    }
}
