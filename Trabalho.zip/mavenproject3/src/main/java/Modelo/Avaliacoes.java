/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import DAO.AvaliacoesDAO;
import java.util.ArrayList;

/**
 *
 * @author Murilo
 */
public class Avaliacoes {
    
    private int codigo;
    private String data_avaliacoes;
    private String nome_materia;
    private String tipo_atividade;
    
    public Avaliacoes(){
        this.codigo = -1;
        this.data_avaliacoes = "";
        this.nome_materia = "";
        this.tipo_atividade = "";
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getData_avaliacoes() {
        return data_avaliacoes;
    }

    public void setData_avaliacoes(String data_avaliacoes) {
        this.data_avaliacoes = data_avaliacoes;
    }

    public String getNome_materia() {
        return nome_materia;
    }

    public void setNome_materia(String nome_materia) {
        this.nome_materia = nome_materia;
    }

    public String getTipo_atividade() {
        return tipo_atividade;
    }

    public void setTipo_atividade(String tipo_atividade) {
        this.tipo_atividade = tipo_atividade;
    }
    
    public void setProximoCodigo(){
        this.codigo = AvaliacoesDAO. ProximoCodigo();
    }
    
    public void Salvar(){
        AvaliacoesDAO.Salvar(this);
    }
    
    public void Excluir(int Chave){
        AvaliacoesDAO.Excluir(Chave);
    }
    
    public void Atualizar(){
        AvaliacoesDAO.Atualizar(this);
    }
    
    public void RecuperarObjeto(int Codigo){
        Avaliacoes avaliacoesTemp = AvaliacoesDAO.RecuperarAvaliacoes(Codigo);
        this.setCodigo(avaliacoesTemp.getCodigo());
        this.setData_avaliacoes(avaliacoesTemp.getData_avaliacoes());
        this.setNome_materia(avaliacoesTemp.getNome_materia());
        this.setTipo_atividade(avaliacoesTemp.getTipo_atividade());
    }
    
    public void RecuperaObjetoPelaNavegacao(int Opcao, int CodigoAtual){
        int CodigoNav = AvaliacoesDAO.PegaCodigoPelaNavegacao(Opcao, CodigoAtual);
        RecuperarObjeto(CodigoNav);
    }
    
    public ArrayList<Avaliacoes> RecuperaObjetos (String pCampo, String pValor){
        
        String NomeCampo = "";
        
        if (pCampo.equalsIgnoreCase("Código")){
            NomeCampo = "CODIGO";
        } else if (pCampo.equalsIgnoreCase("Data da Avaliação")){
            NomeCampo = "DATA_AVALIACOES";
        } else if (pCampo.equalsIgnoreCase("Matéria")){
            NomeCampo = "NOME_MATERIA";
        } else if (pCampo.equalsIgnoreCase("Estilo de Atividade")){
            NomeCampo = "TIPO_ATIVIDADE";
        }
        
        
        return AvaliacoesDAO.RecuperaObjetos(NomeCampo, pValor);
    }
    
}
