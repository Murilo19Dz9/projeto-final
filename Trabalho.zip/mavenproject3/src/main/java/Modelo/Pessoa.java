/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import DAO.PessoaDAO;
import java.util.ArrayList;

/**
 *
 * @author Murilo
 */
public class Pessoa {
    
    private int codigo;
    private String nome;
    private String cpf;
    private String telefone;
    private String endereco;
    private String idade;
    private String email;
    private String escola;
    private String usuario;
    private String senha;

    public Pessoa(){
        this.codigo = -1;
        this.nome = "";
        this.cpf = "";
        this.telefone = "";
        this.endereco = "";
        this.idade = "";
        this.email = "";
        this.escola = "";
        this.usuario = "";
        this.senha = "";
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEscola() {
        return escola;
    }

    public void setEscola(String escola) {
        this.escola = escola;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    public void setProximoCodigo(){
        this.codigo = PessoaDAO. ProximoCodigo();
    }
    
    public void Salvar(){
        PessoaDAO.Salvar(this);
    }
    
    public void Excluir(int Chave){
        PessoaDAO.Excluir(Chave);
    }
    
    public void Atualizar(){
        PessoaDAO.Atualizar(this);
    }
    
    public void RecuperarObjeto(int Codigo){
        Pessoa pessoaTemp = PessoaDAO.RecuperarPessoa(Codigo);
        this.setCodigo(pessoaTemp.getCodigo());
        this.setNome(pessoaTemp.getNome());
        this.setCpf(pessoaTemp.getCpf());
        this.setTelefone(pessoaTemp.getTelefone());
        this.setEndereco(pessoaTemp.getEndereco());
        this.setIdade(pessoaTemp.getIdade());
        this.setEmail(pessoaTemp.getEmail());
        this.setEscola(pessoaTemp.getEscola());
        this.setUsuario(pessoaTemp.getUsuario());
        this.setSenha(pessoaTemp.getSenha());
    }
    
    public void RecuperaObjetoPelaNavegacao(int Opcao, int CodigoAtual){
        int CodigoNav = PessoaDAO.PegaCodigoPelaNavegacao(Opcao, CodigoAtual);
        RecuperarObjeto(CodigoNav);
    }
    
    public ArrayList<Pessoa> RecuperaObjetos (String pCampo, String pValor){
        
        String NomeCampo = "";
        
        if (pCampo.equalsIgnoreCase("Código")){
            NomeCampo = "CODIGO";
        } else if (pCampo.equalsIgnoreCase("Nome")){
            NomeCampo = "NOME";
        } else if (pCampo.equalsIgnoreCase("Cpf")){
            NomeCampo = "CPF";
        } else if (pCampo.equalsIgnoreCase("Email")){
            NomeCampo = "EMAIL";
        }
        
        return PessoaDAO.RecuperaObjetos(NomeCampo, pValor);
    }
}
